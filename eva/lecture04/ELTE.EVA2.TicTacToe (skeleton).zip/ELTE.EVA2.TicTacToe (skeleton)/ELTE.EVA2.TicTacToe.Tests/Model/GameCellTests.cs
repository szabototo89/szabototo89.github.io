﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using ELTE.EVA2.TicTacToe.Model;
using Microsoft.VisualStudio.TestTools.UnitTesting;

namespace ELTE.EVA2.TicTacToe.Tests.Model
{
    [TestClass]
    public class GameCellTests
    {
        [TestMethod]
        public void GameCell_ShouldHaveNonPlayerOwner_WhenNullIsPassedThroughConstructor()
        {
            // Arrange
            var location = new Coordinate(0, 0);
            var underTest = new GameCell(location, null);

            // Act
            var actual = underTest.Owner;

            // Assert
            Assert.AreEqual(Player.NonPlayer, actual);
        }
    }
}