﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using ELTE.EVA2.TicTacToe.Model;
using Microsoft.VisualStudio.TestTools.UnitTesting;

namespace ELTE.EVA2.TicTacToe.Tests.Model
{
    [TestClass]
    public class TicTacToeGameManagerTests
    {
        [TestMethod]
        public void TicTacToeGameManager_ShouldImplementIGameManagerInterface()
        {
            // Arrange + Act
            var underTest = new TicTacToeGameManager();

            // Assert
            Assert.IsInstanceOfType(underTest, typeof (IGameManager));
        }

        [TestClass]
        public class StartGameMethod
        {
            private IEnumerable<Player> players;
            private TicTacToeGameManager underTest;

            [TestInitialize]
            public void Setup()
            {
                players = new[]
                {
                    new Player("player-1"),
                    new Player("player-2"),
                };

                underTest = new TicTacToeGameManager();
            }

            [TestMethod]
            public void ShouldSavePlayers_AfterCallingIt()
            {
                // Arrange in test initialize

                // Act
                underTest.StartGame(players);
                var actualPlayers = underTest.Players;

                // Assert
                var expectedPlayers = new[] {new Player("player-1"), new Player("player-2")};
                Assert.IsNotNull(actualPlayers);
                Assert.IsTrue(actualPlayers.Any(), "actualPlayers doesn't contain any elements.");
                Assert.IsTrue(actualPlayers.SequenceEqual(expectedPlayers));
            }

            [TestMethod]
            public void ShouldSetCurrentGameStatusToPlaying_AfterCallingIt()
            {
                // Arrange in test initialize

                // Act
                underTest.StartGame(players);
                var actualGameStatus = underTest.GameStatus;

                // Assert
                var expectedGameStatus = GameStatus.Playing;
                Assert.AreEqual(expectedGameStatus, actualGameStatus);
            }

            [TestMethod]
            [ExpectedException(typeof (ArgumentNullException))]
            public void ShouldThrowArgumentNullException_WhenNullIsPassedAsPlayers()
            {
                // Arrange in test initialize

                // Act
                underTest.StartGame(null);
            }

            [TestMethod]
            [ExpectedException(typeof (ArgumentException))]
            public void ShouldThrowArgumentException_WhenLessThanTwoPlayersArePassed()
            {
                // Arrange in test initialize

                // Act
                underTest.StartGame(new[] {new Player("player-1")});
            }

            [TestMethod]
            [ExpectedException(typeof (ArgumentException))]
            public void ShouldThrowArgumentException_WhenMoreThanTwoPlayersArePassed()
            {
                // Arrange in test initialize

                // Act
                underTest.StartGame(new[]
                {
                    new Player("player-1"),
                    new Player("player-2"),
                    new Player("player-3")
                });
            }
        }
    }
}