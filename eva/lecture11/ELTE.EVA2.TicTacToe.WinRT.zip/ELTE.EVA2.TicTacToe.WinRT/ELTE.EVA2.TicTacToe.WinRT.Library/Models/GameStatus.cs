﻿namespace ELTE.EVA2.TicTacToe.WinRT.Library.Models
{
    public enum GameStatus
    {
        Playing,
        Stopped
    }
}