﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ELTE.EVA2.TicTacToe.WinRT.Library.Common
{
    public interface IMessageDialogService
    {
        void ShowMessage(String message);
    }
}
