﻿namespace ELTE.EVA2.TicTacToe.View.Model
{
    public enum GameStatus
    {
        Playing,
        Stopped
    }
}