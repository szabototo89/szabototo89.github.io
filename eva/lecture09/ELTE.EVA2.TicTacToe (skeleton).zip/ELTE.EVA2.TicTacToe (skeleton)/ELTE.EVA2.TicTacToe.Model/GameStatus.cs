﻿namespace ELTE.EVA2.TicTacToe.Model
{
    public enum GameStatus
    {
        Playing,
        Stopped
    }
}