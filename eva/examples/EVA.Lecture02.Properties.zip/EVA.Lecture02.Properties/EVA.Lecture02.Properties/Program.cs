﻿using System;

namespace EVA.Lecture02.Properties
{
    public class Person
    {
        private int age;

        public Person()
        {
        }

        public Person(String firstName, String lastName)
        {
            FirstName = firstName;
            LastName = lastName;
        }

        public String FirstName { get; set; } = String.Empty;

        // Default értéket is adhatunk a tulajdonságoknak
        public String LastName { get; set; } = String.Empty;

        public String FullName
        {
            get { return FirstName + " " + LastName; }
        }

        // C# 6.0 nyelvi feature (ekvivalens a fentivel):
        // public String FullName => FirstName + " " + LastName;

        public Int32 Age
        {
            get { return age; }
            set
            {
                // elvégezhetjük a validációt értékadásnál
                if (value < 0) throw new Exception("Age cannot be negative number.");
                age = value;
            }
        }

        public override String ToString()
        {
            // return String.Format("Person({0}, {1}, {2})", FirstName, LastName, Age); // C# 5.0
            // return $"Person({FirstName}, {LastName}, {Age})";  // C# 6.0
            return $"{nameof(Person)}({FirstName}, {LastName}, {Age})";
        }
    }

    public class Program
    {
        private static void WritePerson(Person p)
        {
            Console.WriteLine("Person: {0}({1})", p.FirstName, p.Age);
            Console.ReadKey();
        }

        private static void Main(string[] args)
        {
            Person p = new Person("John", "Doe");
            Console.WriteLine(p.FullName);
            Console.WriteLine(p);
            WritePerson(p);

            p.Age = -10;
            WritePerson(p);

            /*
            // Házi feladat: matematikai vektor implementációja

            Vector vector = new Vector(new[] {1, 2, 3});
            Console.WriteLine(vector.Elements);
            Console.WriteLine(vector.Dimensions);

            Console.WriteLine(Vector.Zero);
            Console.WriteLine(Vector.Create(1, 2, 3, 4) == new Vector(new[] {1, 2, 3, 4}));

            var vector1 = Vector.Create(1, 1, 1);
            var vector2 = Vector.Create(0, 1, 2);
            Console.WriteLine(vector1.Add(vector2) == Vector.Create(1, 2, 3));
            */
        }
    }
}